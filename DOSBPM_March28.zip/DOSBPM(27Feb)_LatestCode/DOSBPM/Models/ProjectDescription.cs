﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DOSBPM.Models
{
    public class ProjectDescription
    {
       public string Notes;
       public string TypeofWork;
    }
}