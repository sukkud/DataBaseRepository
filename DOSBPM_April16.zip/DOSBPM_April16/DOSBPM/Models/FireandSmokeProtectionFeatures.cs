﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Models
{
    public class FireandSmokeProtectionFeatures
    {
        public string txtProvidedHeightSF { get; set; }
        public string txtAllowedHeightSF { get; set; }
        public string txt3CCD { get; set; }
        public string txt3CIS { get; set; }
        public string txt3PgNo { get; set; }
        public string txt3ApplicantComments { get; set; }
        public string txt3BackOffComments { get; set; }

        public SelectList FireBarriersTypeList { get; set; }
        public SelectList FirePartitionTypeList { get; set; }
        public SelectList AdditionalFireSmokeFeaturesList { get; set; }

    }
}