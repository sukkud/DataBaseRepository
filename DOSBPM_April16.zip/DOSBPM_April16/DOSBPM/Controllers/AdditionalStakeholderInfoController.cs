﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Configuration;
using System.Data.SqlClient;
using DOSBPM.Models;

namespace DOSBPM.Controllers
{
    public class AdditionalStakeholderInfoController : BaseController
    {
        DEV_CODES_APPDBEntities db = new DEV_CODES_APPDBEntities();
        // GET: AdditionalStakeholderInfo
        public ActionResult Index()
        {
            Log.Info("Additional Stakeholder Info Controller Started");
            //BuildingApplication buildApp = new BuildingApplication();

            AdditionalStakeholderInfo additionalInfo = new AdditionalStakeholderInfo();
            //additionalInfo.AdditionalStakeholderTypesList = GetAdditionalStakeholderTypes();
            //ViewBag.AdditionalStakeholderTypesList = GetAdditionalStakeholderTypes();
            //return View();

            var objList = new AdditionalStakeholderInfo();
            ViewBag.AdditionalStakeholderTypesList = GetAdditionalStakeholderTypes();
            return View(objList);

            //if (buildApp == null)
            //{
            //    buildApp = new BuildingApplication();
            //    buildApp.AdditionalStakeholderInfoData = new AdditionalStakeholderInfo();
            //}
            //if (buildApp.AdditionalStakeholderInfoData == null)
            //{
            //    buildApp.AdditionalStakeholderInfoData = new AdditionalStakeholderInfo();
            //}

            //buildApp.AdditionalStakeholderInfoData.AdditionalStakeholderTypesList = GetAdditionalStakeholderTypes();

            //return View(buildApp.AdditionalStakeholderInfoData);
        }
    }
}