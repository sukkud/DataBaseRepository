--select * from     [CODES].[T_OwnerInformation]
 SELECT 
			ii.[IndiInfo_FirstName], 
			ii.[IndiInfo_LastName], 
			ii.[IndiInfo_MiddleName], 
			ii.[IndiInfo_Suffix], 
			ci.[PhoneNum],
			ci.[EmailAddress],
			oi.OrgInfo_Name,
			oi.OrgInfo_Authority,
			ads.[Address_ID] , 
			ads.[Address_1], 
			ads.[Address_2], 
			ads.[City] , 
			ads.[StateName], 
			ads.[CountryName], 
			ads.[County_ID], 
			ads.[State_ID], 
			ads.[Country_ID], 
			ads.[ZIP] 
		  FROM   [CODES].[T_OwnerInformation]  owi
			LEFT JOIN [CODES].[BR_OrganizationAddress] oa on owi.BR_OrgAddrID=oa.BR_OrgAddrID
			LEFT JOIN [CODES].[T_OrganizationInformation] oi on oi.OrgInfo_ID=oa.OrgInfo_ID
			LEFT JOIN [CODES].[T_Address] AS ads ON oa.Address_ID = ads.[Address_ID]
			LEFT JOIN [CODES].[BR_IndividualAddress] ia on owi.BR_IndAddrID=ia.BR_IndAddrID
			LEFT JOIN [CODES].[T_IndividualInformation] ii on ii.IndiInfo_ID=ia.IndiInfo_ID
			LEFT JOIN [CODES].[T_ContactInfo] ci on ci.ContactInfo_ID=ia.ContactInfo_ID
		 WHERE  --(ii.[IndiInfo_FirstName] LIKE '%VIN%') OR (ii.[IndiInfo_LastName] LIKE '%VIN%') AND
				 oi.[OrgInfo_Name]='State Of New York'
				 AND (ii.[IndiInfo_FirstName] LIKE '%BR%') OR (ii.[IndiInfo_LastName] LIKE '%BR%') 
		--where OrgInfo_Name='State Of New York'


		--  [CODES].[usp_GetStakeHolderInfo] 'STA','ORG' 

	select *	  FROM   [CODES].[T_OwnerInformation]  owi
			LEFT JOIN [CODES].[BR_OrganizationAddress] oa on owi.BR_OrgAddrID=oa.BR_OrgAddrID
			LEFT JOIN [CODES].[T_OrganizationInformation] oi on oi.OrgInfo_ID=oa.OrgInfo_ID
			LEFT JOIN [CODES].[T_Address] AS ads ON oa.Address_ID = ads.[Address_ID]
			LEFT JOIN [CODES].[BR_IndividualAddress] ia on owi.BR_IndAddrID=ia.BR_IndAddrID
			LEFT JOIN [CODES].[T_IndividualInformation] ii on ii.IndiInfo_ID=ia.IndiInfo_ID
			LEFT JOIN [CODES].[T_ContactInfo] ci on ci.ContactInfo_ID=ia.ContactInfo_ID