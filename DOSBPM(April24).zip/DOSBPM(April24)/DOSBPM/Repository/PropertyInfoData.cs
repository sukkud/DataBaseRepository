﻿using DOSBPM.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DOSBPM.Repository
{
    public class PropertyOwnerData
    {
        DEV_CODES_APPDBEntities db = null;
        public PropertyOwnerData()
        {
            db = new DEV_CODES_APPDBEntities();

        }
        public List<StakeInfo> GetStackInfoData(string searchStr, string type)
        {
            var data = db.usp_GetStakeHolderInfon(searchStr, type).ToList();
            List<StakeInfo> result = (from sh in data
                                      select new StakeInfo
                                      {
                                          FirstName = sh.IndiInfo_FirstName,
                                          LastName = sh.IndiInfo_LastName,
                                          Middle = sh.IndiInfo_MiddleName,
                                          Suffix = sh.IndiInfo_Suffix,
                                          OrgName = sh.OrgInfo_Name,
                                          OrgAuthority = sh.OrgInfo_Authority,
                                          AddressId = sh.Address_ID,
                                          Address1 = sh.Address_1,
                                          Address2 = sh.Address_2,
                                          City = sh.City,
                                          StateName = sh.StateName,
                                          CountryName = sh.CountryName,
                                          //Zip = (sh.ZIP.HasValue ? sh.ZIP.Value : 0),
                                          Zip = sh.ZIP,
                                          CountyId = sh.County_ID,
                                          StateId = sh.State_ID,
                                          CountryId = sh.Country_ID,
                                          TelephoneNumber = sh.PhoneNum,
                                          EmailId = sh.EmailAddress
                                      }).ToList();

            return result;

        }
    }
    
}