﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Controllers
{
    public class SearchTransactionsController : Controller
    {
        // GET: SearchTransactions
        public ActionResult Index()
        {
            return View();
        }
    }
}