﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DOSBPM.Models;
using DOSBPM.Repository;
using Newtonsoft.Json;

namespace DOSBPM.Controllers
{
    public class PropertyOwnerContactController : BaseController
    {
        // GET: PropertyOwnerContact

        DEV_CODES_APPDBEntities db = new DEV_CODES_APPDBEntities();

        public ActionResult Index()
        {

            BuildingApplication buildApp = new BuildingApplication();
            PropertyOwnerContact propertyOwnerContact = new PropertyOwnerContact();

            if (Session["BuildingApplication"] != null)
            {
                buildApp = (BuildingApplication)Session["BuildingApplication"];
            }
            else
            {
                string jsonData = string.Empty;
                Temp_BPMData objtemp_BPMData = db.Temp_BPMData.FirstOrDefault(x => x.AppID == "3" && x.UserID == "3");
                if (objtemp_BPMData != null)
                {
                    jsonData = objtemp_BPMData.JsonData;
                }
                buildApp = JsonConvert.DeserializeObject<BuildingApplication>(jsonData);
            }
            if (buildApp == null)
            {
                buildApp = new BuildingApplication();
            }
            buildApp.PropertyOwnerContactData = (buildApp.PropertyOwnerContactData == null) ? new PropertyOwnerContact() : buildApp.PropertyOwnerContactData;
            buildApp.PropertyOwnerContactData.AddressInfo = (buildApp.PropertyOwnerContactData.AddressInfo == null) ? new AddressInfo() : buildApp.PropertyOwnerContactData.AddressInfo;

            //buildApp.PropertyOwnerContactData.StakeholderTypeList = GetStakeholderTypes();
            buildApp.PropertyOwnerContactData.StakeholderType = "SH_1";          
            buildApp.PropertyOwnerContactData.SuffixList = GetSuffixTypes();

            AddressInfo objAddressInfo = new AddressInfo();
            buildApp.PropertyOwnerContactData.AddressInfo.CountryList = objAddressInfo.CountryList;
            buildApp.PropertyOwnerContactData.AddressInfo.StatesList = objAddressInfo.StatesList;
            buildApp.PropertyOwnerContactData.AddressInfo.CountiesList = objAddressInfo.CountiesList;
            buildApp.PropertyOwnerContactData.PropertyOwner = buildApp.PropertyOwnerInfoData.OrganizationName;

            return View(buildApp.PropertyOwnerContactData);
            //return View();


        }
        [HttpPost]
        public ActionResult Index(PropertyOwnerContact propertyOwnerContact)
        {
            BuildingApplication buildApp = null;
            if (Session["BuildingApplication"] != null)
            {
                buildApp = (BuildingApplication)Session["BuildingApplication"];
            }
            else
            {
                buildApp = new BuildingApplication();
            }

            propertyOwnerContact.AddressInfo.CountiesList = null;
            propertyOwnerContact.AddressInfo.StatesList = null;
            propertyOwnerContact.AddressInfo.CountryList = null;
            propertyOwnerContact.StakeholderTypeList = null;
            propertyOwnerContact.SuffixList = null;

            if (buildApp.QualifyingInfoData != null)
            {
                buildApp.QualifyingInfoData.TransactionTypeList = null;
            }
            if (buildApp.PropertyOwnerInfoData != null)
            {
                buildApp.PropertyOwnerInfoData.StakeholderTypeList = null;
                buildApp.PropertyOwnerInfoData.SuffixList = null;
                buildApp.PropertyOwnerInfoData.AddressInfo.CountiesList = null;
                buildApp.PropertyOwnerInfoData.AddressInfo.StatesList = null;
                buildApp.PropertyOwnerInfoData.AddressInfo.CountryList = null;
            }
            buildApp.PropertyOwnerContactData = propertyOwnerContact;
            Session["BuildingApplication"] = buildApp;

            string buildAppString = JsonConvert.SerializeObject(buildApp);

            Temp_BPMData objtemp_BPMData = db.Temp_BPMData.FirstOrDefault(x => x.AppID == "3" && x.UserID == "3");
            if (objtemp_BPMData != null)
            {
                objtemp_BPMData.AppID = "3";
                objtemp_BPMData.UserID = "3";
                objtemp_BPMData.JsonData = buildAppString;
                db.SaveChanges();
            }
            else
            {
                Temp_BPMData objtempBPM = new Temp_BPMData();
                objtempBPM.AppID = "3";
                objtempBPM.UserID = "3";

                objtempBPM.JsonData = buildAppString;
                db.Temp_BPMData.Add(objtempBPM);
                db.SaveChanges();
            }
           
                return RedirectToAction("Index", "AdditionalStakeholderInfo");
            
           

        }
        [HttpPost]
        public JsonResult GetStackHolder(string stackHolder, string type)
        {
            List<StakeInfo> stackHolders = new List<StakeInfo>();
            var resp = new PropertyOwnerData();
            stackHolders = resp.GetStackInfoData(stackHolder, type);
            return Json(stackHolders, JsonRequestBehavior.AllowGet);
        }
    }
}