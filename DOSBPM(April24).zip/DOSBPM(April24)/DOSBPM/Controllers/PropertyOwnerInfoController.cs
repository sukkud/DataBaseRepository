﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Configuration;
using System.Data.SqlClient;
using DOSBPM.Models;
using Newtonsoft.Json;
using DOSBPM.Repository;

namespace DOSBPM.Controllers
{
    public class PropertyOwnerInfoController : BaseController
    {
        // GET: PropertyOwnerInfo
        DEV_CODES_APPDBEntities db = new DEV_CODES_APPDBEntities();

        public ActionResult Index()
        {
            BuildingApplication buildApp = new BuildingApplication();
            PropertyOwnerInfo propertyOwnerInfo = new PropertyOwnerInfo();

            if (Session["BuildingApplication"] != null)
            {
                buildApp = (BuildingApplication)Session["BuildingApplication"];
            }
            else
            {
                string jsonData = string.Empty;
                Temp_BPMData objtemp_BPMData = db.Temp_BPMData.FirstOrDefault(x => x.AppID == "3" && x.UserID == "3");
                if (objtemp_BPMData != null)
                {
                    jsonData = objtemp_BPMData.JsonData;
                }
                buildApp = JsonConvert.DeserializeObject<BuildingApplication>(jsonData);
            }
            if (buildApp == null)
            {
                buildApp = new BuildingApplication();
                //buildApp.PropertyOwnerInfoData = new PropertyOwnerInfo();

            }

            //ViewBag.info = new List<SelectListItem> {
            //                                            new SelectListItem {Value="Property Owner Organization", Text="Property Owner Organization", Selected=(buildApp.PropertyOwnerInfoData?.PropertyOwnerType=="Property Owner Organization")},
            //                                            new SelectListItem {Value="Property Owner Individual", Text="Property Owner Individual", Selected=(buildApp.PropertyOwnerInfoData?.PropertyOwnerType=="Property Owner Individual")}

            //                                        };

            buildApp.PropertyOwnerInfoData = (buildApp.PropertyOwnerInfoData == null) ? new PropertyOwnerInfo() : buildApp.PropertyOwnerInfoData;
            buildApp.PropertyOwnerInfoData.AddressInfo = (buildApp.PropertyOwnerInfoData.AddressInfo == null) ? new AddressInfo() : buildApp.PropertyOwnerInfoData.AddressInfo;

            buildApp.PropertyOwnerInfoData.StakeholderTypeList = GetStakeholderTypes();
            buildApp.PropertyOwnerInfoData.SuffixList = GetSuffixTypes();

            AddressInfo objAddressInfo = new AddressInfo();
            buildApp.PropertyOwnerInfoData.AddressInfo.CountryList = objAddressInfo.CountryList;
            buildApp.PropertyOwnerInfoData.AddressInfo.StatesList = objAddressInfo.StatesList;
            buildApp.PropertyOwnerInfoData.AddressInfo.CountiesList = objAddressInfo.CountiesList;


            //ViewBag.StakeholderTypeList = GetStakeholderTypes();
            //ViewBag.StatesList = GetStates();
            //ViewBag.CountryList = GetCountries();
            //ViewBag.CountiesList = GetCounties();

            //buildApp.PropertyOwnerInfoData.StakeholderTypeList = GetStakeholderTypes();

            return View(buildApp.PropertyOwnerInfoData);


        }
        [HttpPost]
        public ActionResult Index(PropertyOwnerInfo propertyOwnerInfo)
        {
            BuildingApplication buildApp = null;
            if (Session["BuildingApplication"] != null)
            {
                buildApp = (BuildingApplication)Session["BuildingApplication"];
            }
            else
            {
                    buildApp = new BuildingApplication();
                }

            propertyOwnerInfo.AddressInfo.CountiesList = null;
            propertyOwnerInfo.AddressInfo.StatesList = null;
            propertyOwnerInfo.AddressInfo.CountryList = null;
            propertyOwnerInfo.StakeholderTypeList = null;
            propertyOwnerInfo.SuffixList = null;

            if (buildApp.QualifyingInfoData != null)
            {
                buildApp.QualifyingInfoData.TransactionTypeList = null;
            }
            if (buildApp.PropertyOwnerContactData != null)
            {
                buildApp.PropertyOwnerContactData.StakeholderTypeList = null;
                buildApp.PropertyOwnerContactData.SuffixList = null;
                buildApp.PropertyOwnerContactData.AddressInfo.CountiesList = null;
                buildApp.PropertyOwnerContactData.AddressInfo.StatesList = null;
                buildApp.PropertyOwnerContactData.AddressInfo.CountryList = null;
            }
            buildApp.PropertyOwnerInfoData = propertyOwnerInfo;
            Session["BuildingApplication"] = buildApp;

            string buildAppString = JsonConvert.SerializeObject(buildApp);
           
            Temp_BPMData objtemp_BPMData = db.Temp_BPMData.FirstOrDefault(x => x.AppID == "3" && x.UserID == "3");
            if (objtemp_BPMData != null)
            {
                objtemp_BPMData.AppID = "3";
                objtemp_BPMData.UserID = "3";              
                objtemp_BPMData.JsonData = buildAppString;
                
                db.SaveChanges();
            }
            else
            {
                Temp_BPMData objtempBPM = new Temp_BPMData();
                objtempBPM.AppID = "3";
                objtempBPM.UserID = "3";

                objtempBPM.JsonData = buildAppString;
                db.Temp_BPMData.Add(objtempBPM);
                db.SaveChanges();
            }
            if (propertyOwnerInfo.StakeholderType == "SH_1")
            {
                return RedirectToAction("Index", "PropertyOwnerContact");
            }
            else
            {
                return RedirectToAction("Index", "AdditionalStakeholderInfo");
            }

        }
        [HttpPost]
        public JsonResult GetStackHolder(string stackHolder, string type)
        {
            List<StakeInfo> stackHolders = new List<StakeInfo>();
            var resp = new PropertyOwnerData();
            stackHolders = resp.GetStackInfoData(stackHolder, type);
            return Json(stackHolders, JsonRequestBehavior.AllowGet);
        }
    }
}