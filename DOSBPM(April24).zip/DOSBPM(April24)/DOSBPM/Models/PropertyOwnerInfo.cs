﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Models
{
    public class PropertyOwnerInfo: IBuildingInfo
    {
         
        public string FirstName { get; set; }
        public string MiddleName { get; set; }       
        public string LastName { get; set; }
        public string Suffix { get; set; }
        public string TelephoneNumber { get; set; }
        public string EmailId { get; set; }      
        public string SiteDirection { get; set; }
        public string Comments { get; set; }
        public string Authority { get; set; } // Same for Orgnization address and Contact person address
        public string JobTitle { get; set; }
        public string PropertyOwner { get; set; }
        public string searchStakeHolderName { get; set; }
        public string OrganizationName { get; set; }
        public string BuildingName { get; set; }
        public int ParcelTaxID { get; set; }

        public string StakeholderType { get; set; }
        public SelectList StakeholderTypeList { get; set; }

        public SelectList SuffixList { get; set; }

        public AddressInfo AddressInfo { get; set; }

        //Edit buttons update and Create new records
        public bool IsUpdateRecord { get; set; }
        public bool IsNewRecord { get; set; }
    }
}