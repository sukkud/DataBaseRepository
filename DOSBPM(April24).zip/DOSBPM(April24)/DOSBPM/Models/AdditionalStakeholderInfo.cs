﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Models
{
    public class AdditionalStakeholderInfo
    {
        public string AdditionalStakeholderType { get; set; }

        public SelectList AdditionalStakeholderTypesList { get; set; }

        public string OrgName { get; set; }
        
        
        public string MailingAddressLine1 { get; set; }
        public string MailingAddressLine2 { get; set; }
        
        public string City { get; set; }
        
        public string State { get; set; }
        
        public int Zip { get; set; }
        public int Zip4 { get; set; }
        
        public string County { get; set; }
       
        public string Country { get; set; }
        public string Comments { get; set; }

        public string Exceptions { get; set; }
       
}
}