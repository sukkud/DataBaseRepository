﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Controllers
{
    public class BaseController : Controller
    {
        DEV_CODES_APPDBEntities appdbEntities = new DEV_CODES_APPDBEntities();
        public SelectList GetTransactionTypes()
            {
                return new SelectList(appdbEntities.L_TransactionType, "TransType_ID", "TransType_Name");
            }
           public SelectList GetStakeholderTypes()
            {
             return new SelectList(appdbEntities.L_StakeHolderType, "StkHoldType_ID", "StkHoldType_Name");
             }

            public SelectList GetStates()
            {
                return new SelectList(appdbEntities.L_State, "State_ID", "State_Name");
            }
            public SelectList GetCountries()
            {
                return new SelectList(appdbEntities.L_Country, "Country_ID", "Country_Name");
            }

            public SelectList GetCounties()
            {
                return new SelectList(appdbEntities.L_County, "County_ID", "County_Name");
            }

        public SelectList GetOccupancyType()
        {
            return new SelectList(appdbEntities.L_OccupancyTypes, "OccupancyType_ID", "OccupancyType_Code");
        }

        public SelectList GetConstructionType()
        {
            return new SelectList(appdbEntities.L_ConstructionType, "ConstructionType_ID", "ConstructionType_Description");
        }

        public SelectList GetWaterSupplyType()
        {
            return new SelectList(appdbEntities.L_WaterSupplyType, "WaterSupplyType_ID", "WaterSupplyType_Description");
        }

        public SelectList GetWasteWaterSupplyType()
        {
            return new SelectList(appdbEntities.L_WasterWaterSupplyType, "WasterWaterSupplyType_ID", "WasterWaterSupplyType_Description");
        }
        public SelectList GetPaymentType()
        {
            return new SelectList(appdbEntities.L_PaymentType, "PaymentType_ID", "PaymentType_Description");
        }

        public SelectList GetWorkType()
        {
            return new SelectList(appdbEntities.L_WorkType, "WorkType_ID", "WorkTypeDescription");
        }


        public SelectList GetAsbestoesReasonType()
        {
            return new SelectList(appdbEntities.L_AsbestoesReason, "AsbestoesReason_ID", "AsbestoesReason_LDescription");
        }

        public SelectList GetSpecialDetailedReqType()
        {
            return new SelectList(appdbEntities.L_SpecialDetailedReq, "SpecialDetailedReq_ID", "SpecialDetailedReq_Description");
        }

        public SelectList GetFireBarriersType()
        {
            return new SelectList(appdbEntities.L_FireBarriers, "FireBarriers_ID", "FireBarriers_Description");
        }

        public SelectList GetFirePartitionType()
        {
            return new SelectList(appdbEntities.L_FirePartition, "FirePartition_ID", "FirePartition_Description");
        }


        public SelectList GetAdditionalFireSmokeFeaturesType()
        {
            return new SelectList(appdbEntities.L_AdditionalFireSmokeFeatures, "AdditionalFireSmokeFeatures_ID", "AdditionalFireSmokeFeatures_Description");
        }

        public SelectList GetElectricalServiceType()
        {
            return new SelectList(appdbEntities.L_ElectricalServiceType, "ElectricalServiceType_ID", "ElectricalServiceType_Description");
        }


        public SelectList GetNumberofPropaneTanks()
        {
            return new SelectList(appdbEntities.L_PropaneTanks, "PropaneTanks_ID", "PropaneTanks_Description");
        }


        public SelectList GetGasFuelOilType()
        {
            return new SelectList(appdbEntities.L_GasFuelOilType, "GasFuelOilType_ID", "GasFuelOilType_Description");
        }


        public SelectList GetNumberofFuelOilTanks()
        {
            return new SelectList(appdbEntities.L_FuelOilTanks, "FuelOilTanks_ID", "FuelOilTanks_Description");
        }

        public SelectList GetTypeOfElectricalSystem()
        {
            return new SelectList(appdbEntities.L_TypeOfElectricalSystem, "ElectricalSystemType_ID", "ElectricalSystemType_Description");
        }


        public SelectList GetClimateZone()
        {
            return new SelectList(appdbEntities.L_CilmateZone, "ClimateZone_ID", "ClimateZone_Description");
        }


        public SelectList GetCompliancePath()
        {
            return new SelectList(appdbEntities.L_CompliancePath, "CompliancePath_ID", "CompliancePath_Description");
        }


        public SelectList GetComplianceSoftware()
        {
            return new SelectList(appdbEntities.L_ComplianceSoftware, "ComplianceSoftware_ID", "ComplianceSoftware_Description");
        }

        public SelectList GetRiskCategory()
        {
            return new SelectList(appdbEntities.L_RiskCategory, "RiskCategory_ID", "RiskCategory_Description");
        }
        public SelectList GetSeismicDesignCategory()
        {
            return new SelectList(appdbEntities.L_SeismicDesignCategory, "SeismicDesignCategory_ID", "SeismicDesignCategory_Description");
        }

        public SelectList GetEgressSystems()
        {
            return new SelectList(appdbEntities.L_SeismicDesignCategory, "SeismicDesignCategory_ID", "SeismicDesignCategory_Description");
        }

        public SelectList GetAdditionalFireProtectionSystems()
        {
            return new SelectList(appdbEntities.L_FireProtectionSystem, "FireProtectionSystem_ID", "FireProtectionSystem_Description");
        }

    }
}