﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Configuration;
using System.Data.SqlClient;
using DOSBPM.Models;
using Newtonsoft.Json;


namespace DOSBPM.Controllers
{
    public class QualifyingInfoController : BaseController
    {
        DEV_CODES_APPDBEntities db = new DEV_CODES_APPDBEntities();

        // GET: QualifyingInfo
        public ActionResult Index()
        {
            Log.Info("Qualifying Info Controller Started");
            //While Loading Deserialization
            BuildingApplication buildApp = new BuildingApplication();
            QualifyingInfo qualifyingInfo = new QualifyingInfo();
                       

            if (Session["BuildingApplication"] != null)
            {
                var data = (BuildingApplication)Session["BuildingApplication"];

                buildApp.QualifyingInfoData = data.QualifyingInfoData;


            }
            else
            {
                string jsonData = string.Empty;
                if (db.temp_BPMData != null)

                {
                    temp_BPMData objtemp_BPMData = db.temp_BPMData.FirstOrDefault(x => x.AppID == "1" && x.UserID == "1");
                    if (objtemp_BPMData != null)
                    {
                        jsonData = objtemp_BPMData.JsonData;
                    }

                    buildApp = JsonConvert.DeserializeObject<BuildingApplication>(jsonData);
                }
                 
            }

            if (buildApp == null)
            {
                buildApp = new BuildingApplication();
                buildApp.QualifyingInfoData = new QualifyingInfo();
            }
            if (buildApp.QualifyingInfoData == null)
            {
                buildApp.QualifyingInfoData = new QualifyingInfo();
            }

            //ViewBag.info = new List<SelectListItem> {
            //                                            new SelectListItem {Value = "1", Text="Building Permit Application", Selected = (buildApp.QualifyingInfoData?.TransactionType=="1")},
            //                                            new SelectListItem {Value = "2", Text="Demolition Permit Application", Selected=(buildApp.QualifyingInfoData?.TransactionType=="2")}

            //                                         };


            buildApp.QualifyingInfoData.TransactionTypeList = GetTransactionTypes();
            //ViewBag.TransactionTypeList = GetTransactionTypes();
            return View(buildApp.QualifyingInfoData);
        }
        [HttpPost]
        public ActionResult Index(QualifyingInfo qualifyingInfo)
        {
            //store in session
            BuildingApplication buildApp = null;
            if (Session["BuildingApplication"] != null)
            {
                buildApp = (BuildingApplication)Session["BuildingApplication"];
            }
            else
            {

                string jsonData = string.Empty;
                if (db.temp_BPMData != null)

                {
                    temp_BPMData objtemp_BPMData1 = db.temp_BPMData.FirstOrDefault(x => x.AppID == "1" && x.UserID == "1");
                    if (objtemp_BPMData1 != null)
                    {
                        jsonData = objtemp_BPMData1.JsonData;
                    }

                    buildApp = JsonConvert.DeserializeObject<BuildingApplication>(jsonData);
                }
                if (buildApp == null)
                {
                    buildApp = new BuildingApplication();
                }

            }
            qualifyingInfo.TransactionTypeList = null; //json exception fixed and the list should not save only one list item needs to save.

            if (buildApp.PropertyOwnerInfoData != null)
            {
               buildApp.PropertyOwnerInfoData.AddressInfo.CountiesList = null;
               buildApp.PropertyOwnerInfoData.AddressInfo.StatesList = null;
               buildApp.PropertyOwnerInfoData.AddressInfo.CountryList = null;
               buildApp.PropertyOwnerInfoData.StakeholderTypeList = null;
            }

            buildApp.QualifyingInfoData = qualifyingInfo;
            Session["BuildingApplication"] = buildApp;

            string buildAppString = JsonConvert.SerializeObject(buildApp);
            temp_BPMData objtemp_BPMData = db.temp_BPMData.FirstOrDefault(x => x.AppID == "1" && x.UserID == "1");
            if (objtemp_BPMData != null)
            {
                objtemp_BPMData.AppID = "1";
                objtemp_BPMData.UserID = "1";
                objtemp_BPMData.JsonData = buildAppString;
                db.SaveChanges();
            }
            else
            {
                temp_BPMData objtempBPM = new temp_BPMData();
                objtempBPM.AppID = "1";
                objtempBPM.UserID = "1";
                objtempBPM.JsonData = buildAppString;
                db.temp_BPMData.Add(objtempBPM);
                db.SaveChanges();
            }


            return RedirectToAction("Index", "PropertyOwnerInfo");
        }
    }
}