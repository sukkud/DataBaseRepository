﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DOSBPM.Models;

namespace DOSBPM.Controllers
{
    public class ElectricalRequirementsController : BaseController
    {
        // GET: ElectricalRequirements
        public ActionResult Index()
        {
            Log.Info("Electrical Requirements Controller Started");

            var objList = new ElectricalRequirements();
            objList.TypeOfElectricalSystemList = GetTypeOfElectricalSystem();
            
            return View(objList);

            
        }
    }
}