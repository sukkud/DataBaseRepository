﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DOSBPM.Models;


namespace DOSBPM.Controllers
{
    public class SiteandUtilitiesController : BaseController
    {

        DEV_CODES_APPDB1Entities appdbEntities = new DEV_CODES_APPDB1Entities();


        // GET: SiteandUtilities
        public ActionResult Index()
        {
            Log.Info("Site and Utilities Controller Started");

            var objList = new SiteandUtilities();
            objList.WaterSupplyTypeList = GetWaterSupplyType();
            objList.WasteWaterSupplyTypeList = GetWasteWaterSupplyType();
            objList.ElectricalServiceTypeList = GetElectricalServiceType();
            objList.PropaneTankList = GetNumberofPropaneTanks();
            objList.GasOilFuelTypeList = GetGasFuelOilType();
            objList.FuelOiltankList = GetNumberofFuelOilTanks();

           return View(objList);

        }
    }
}