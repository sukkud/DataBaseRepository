﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DOSBPM.Models;

namespace DOSBPM.Controllers
{
    public class StructrualDesignController : BaseController
    {
        DEV_CODES_APPDBEntities appdbEntities = new DEV_CODES_APPDBEntities();

        // GET: StructrualDesign
        public ActionResult Index()
        {
            Log.Info("Structrual Design Controller Started");

            var objList = new StructrualDesign();
            objList.RiskCategoryList = GetRiskCategory();
            objList.SeismicDesignCategoryList = GetSeismicDesignCategory();

            return View(objList);
        }
    }
}