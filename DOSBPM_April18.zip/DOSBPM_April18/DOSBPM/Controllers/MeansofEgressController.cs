﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DOSBPM.Models;

namespace DOSBPM.Controllers
{
    public class MeansofEgressController : BaseController
    {
        // GET: MeansofEgress
        public ActionResult Index()
        {
            Log.Info("Means of Egress Controller Started");

            var objList = new MeansofEgress();
            objList.EgressSystemsList = GetEgressSystems();

            return View(objList);
        }
    }
}