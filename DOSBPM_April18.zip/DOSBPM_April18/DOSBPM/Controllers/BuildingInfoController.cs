﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DOSBPM.Models;
using Newtonsoft.Json;
using DOSBPM.Repository;

namespace DOSBPM.Controllers
{
    public class BuildingInfoController : BaseController
    {
        // GET: BuildingInfo
        DEV_CODES_APPDBEntities db = new DEV_CODES_APPDBEntities();


        public ActionResult Index()
        {
            //Log.Info("Building Info Controller Started test1");

            //return View();

            BuildingApplication buildApp = new BuildingApplication();
            
            BuildingInfo buildingInfo = new BuildingInfo();

            //if (Session["BuildingApplication"] != null)
            //{
            //    buildApp = (BuildingApplication)Session["BuildingApplication"];
            //}
            //else
            //{
            //    string jsonData = string.Empty;
            //    Temp_BPMData objtemp_BPMData = db.Temp_BPMData.FirstOrDefault(x => x.AppID == "3" && x.UserID == "3");
            //    if (objtemp_BPMData != null)
            //    {
            //        jsonData = objtemp_BPMData.JsonData;
            //    }
            //    buildApp = JsonConvert.DeserializeObject<BuildingApplication>(jsonData);
            //}
            //if (buildApp == null)
            //{
            //    buildApp = new BuildingApplication();
            //buildApp.PropertyOwnerInfoData = new PropertyOwnerInfo();

            // }

            //ViewBag.info = new List<SelectListItem> {
            //                                            new SelectListItem {Value="Property Owner Organization", Text="Property Owner Organization", Selected=(buildApp.PropertyOwnerInfoData?.PropertyOwnerType=="Property Owner Organization")},
            //                                            new SelectListItem {Value="Property Owner Individual", Text="Property Owner Individual", Selected=(buildApp.PropertyOwnerInfoData?.PropertyOwnerType=="Property Owner Individual")}

            //                                        };

            buildApp.BuildingData = (buildApp.BuildingData == null) ? new BuildingInfo() : buildApp.BuildingData;
            buildApp.BuildingData.AddressInfo = (buildApp.BuildingData.AddressInfo == null) ? new AddressInfo() : buildApp.BuildingData.AddressInfo;

            buildApp.BuildingData.StakeholderTypeList = GetStakeholderTypes();
            buildApp.BuildingData.SuffixList = GetSuffixTypes();

            AddressInfo objAddressInfoBld = new AddressInfo();
            buildApp.BuildingData.AddressInfo.CountryList = objAddressInfoBld.CountryList;
            buildApp.BuildingData.AddressInfo.StatesList = objAddressInfoBld.StatesList;
            buildApp.BuildingData.AddressInfo.CountiesList = objAddressInfoBld.CountiesList;


            //ViewBag.StakeholderTypeList = GetStakeholderTypes();
            //ViewBag.StatesList = GetStates();
            //ViewBag.CountryList = GetCountries();
            //ViewBag.CountiesList = GetCounties();

            //buildApp.PropertyOwnerInfoData.StakeholderTypeList = GetStakeholderTypes();

            return View(buildApp.BuildingData);


        }
    }
    
}