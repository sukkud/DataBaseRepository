﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Models
{
    public class MiscAdditionalInfo
    {
        public string AsbestoesReason { get; set; }
        public SelectList AsbestoesReasonTypeList { get; set; }
    }
}