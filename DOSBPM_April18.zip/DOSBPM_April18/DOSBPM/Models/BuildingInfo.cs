﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Models
{
    public class BuildingInfo: IBuildingInfo
    {

        public string BuildingName { get; set; }     
        public string SiteDirection { get; set; }
        public int ParcelTaxID { get; set; }
        public SelectList StakeholderTypeList { get; set; }
        public SelectList SuffixList { get; set; }

        //Edit buttons update and Create new records
        public bool IsUpdateRecord { get; set; }
        public bool IsNewRecord { get; set; }

        public PropertyOwnerInfo buildingInfo { get; set; }
        public AddressInfo AddressInfo { get; set; }

    }
}