﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DOSBPM.Models;

namespace DOSBPM.Controllers
{
    public class FireandSmokeProtectionFeaturesController : BaseController
    {
        // GET: FireandSmokeProtectionFeatures
        public ActionResult Index()
        {
            Log.Info("Fire and Smoke Protection Features Controller Started");

            var objList = new FireandSmokeProtectionFeatures();
            objList.FireBarriersTypeList = GetFireBarriersType();
            objList.FirePartitionTypeList = GetFirePartitionType();
            objList.AdditionalFireSmokeFeaturesList = GetAdditionalFireSmokeFeaturesType();

            return View(objList);

        }
    }
}