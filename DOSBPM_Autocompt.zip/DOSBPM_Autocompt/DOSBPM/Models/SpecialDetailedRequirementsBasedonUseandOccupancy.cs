﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Models
{
    public class SpecialDetailedRequirementsBasedonUseandOccupancy
    {
        public string txt1CCD { get; set; }
        public string txt1CIS { get; set; }
        public string txt1PgNo { get; set; }
        public string txt1ApplicantComments { get; set; }
        public string txt1BackOffComments { get; set; }
        
        public string SpecialDetailReq { get; set; }
        public SelectList SpecialDetailReqList { get; set; }
    }
}