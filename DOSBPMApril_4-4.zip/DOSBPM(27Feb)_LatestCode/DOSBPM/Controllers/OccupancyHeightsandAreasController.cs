﻿using DOSBPM.Models;
using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;



namespace DOSBPM.Controllers
{
    public class OccupancyHeightsandAreasController : BaseController
    {
        DEV_CODES_APPDBEntities db = new DEV_CODES_APPDBEntities();
        // GET: OccupancyHeightsandAreas

        [HttpGet]
        public ActionResult Index()
        {

            Log.Info("Occupancy Heights and Areas Controller Started");

            ViewBag.ConstructionTypeList = GetConstructionType();
            ViewBag.OccupancyTypeList = GetOccupancyType();


            return View();




        }

        [HttpPost]
        public ActionResult Index(OccupancyHeightsandAreas occupancyHeightsandAreas)
        {

            
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            String JSON = javaScriptSerializer.Serialize(occupancyHeightsandAreas);
            OccupancyHeightsandAreas.Name = "BP";
            OccupancyHeightsandAreas.DESCP = JSON;
           
            




            //BusinessLogic businessLogic = new BusinessLogic();
            //businessLogic.AddNewPermit(occupancyHeightsandAreas);

            //string occupationclassification = occupancyHeightsandAreas.OccupancyType_Code;
            // string typepfConstruction = occupancyHeightsandAreas.ConstructionType_Description;


            //Temp_BPMData objTemp_BPMData = db.Temp_BPMData.FirstOrDefault(x => x.AppID == "1" && x.UserID == "1");
            //Console.WriteLine(JSON);
            return RedirectToAction("Index", "VarianceQuestions");



        }


    }
}