﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Models
{
    public class OccupancyHeightsandAreas
    {
        public static string Name { get; internal set; }        
        public static string DESCP { get; internal set; }
        public string  abandoned { get; set; }

        public string ApplicantComments { get; set; }

        public string ReviewerComments { get; set; }
        public double BuildingHeightinStories { get; set; }
        public double BuildingHeightinFeets { get; set; }
        public double FloorAreainStories { get; set; }
        public double FloorAreainFeets { get; set; }
        public int BuildingYear { get; set; }

        public string ConstructionType_Description { get; set; }
        public string OccupancyType_Code { get; set; }
        public SelectList ConstructionTypeList { get; set; }
        public SelectList OccupancyTypeList { get; set; }
    }
}