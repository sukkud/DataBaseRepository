﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Models
{
    public class ProjectDescription
    {
       public string Notes;
       public string TypeofWork;
       public SelectList WorkTypeList;

    }
}