﻿using DOSBPM.Models;
using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;



namespace DOSBPM.Controllers
{
    public class OccupancyHeightsandAreasController : BaseController
    {
        DEV_CODES_APPDB1Entities appdbEntities = new DEV_CODES_APPDB1Entities();
        // GET: OccupancyHeightsandAreas

            [HttpGet]
        public ActionResult Index()
        {


            Log.Info("Occupancy Heights and Areas Controller Started");


            //var objList = new OccupancyHeightsandAreas();
            //objList.ConstructionTypeList = GetConstructionType();
            //objList.OccupancyTypeList = GetOccupancyType();

            var objList = new DEV_CODES_APPDB1Entities();

            ViewBag.ConstructionType_ID = new SelectList(objList.L_ConstructionType, "ConstructionType_ID", "ConstructionType_Description");
            ViewBag.OccupancyType_ID = new SelectList(objList.L_OccupancyTypes, "OccupancyType_ID", "OccupancyType_Code");


            return View();


            
          
        }

        [HttpPost]
        public ActionResult Index(OccupancyHeightsandAreas occupancyHeightsandAreas)
        {
          
            List<OccupancyHeightsandAreas> occupancyheight = new List<OccupancyHeightsandAreas>();
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            String JSON = javaScriptSerializer.Serialize(occupancyHeightsandAreas);
            Console.WriteLine(JSON);
            return RedirectToAction("Index", "VarianceQuestions");
        }


    }
}