﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DOSBPM.Models;

namespace DOSBPM.Controllers
{
    public class EnergyRequirementsController : BaseController
    {
        DEV_CODES_APPDB1Entities appdbEntities = new DEV_CODES_APPDB1Entities();

        // GET: EnergyRequirements
        public ActionResult Index()
        {
            Log.Info("Energy Requirements Controller Started");

            var objList = new EnergyRequirements();
            objList.ClimateZoneList = GetClimateZone();
            objList.CompliancePathList = GetCompliancePath();
            objList.ComplianceSoftwareList = GetComplianceSoftware();
           
            return View(objList);
                        
        }
    }
}