﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DOSBPM.Models;

namespace DOSBPM.Controllers
{
    public class GeneralBuildingHeightsandAreasController : BaseController
    {
        DEV_CODES_APPDB1Entities appdbEntities = new DEV_CODES_APPDB1Entities();
        // GET: GeneralBuildingHeightsandAreas
        public ActionResult Index()
        {
            Log.Info("General Building Heights and Areas Controller Started");
            var objList = new GeneralBuildingHeightsandAreas();
            objList.AdditionalOccupancies = GetOccupancyType();
            return View(objList);
        }
    }
}