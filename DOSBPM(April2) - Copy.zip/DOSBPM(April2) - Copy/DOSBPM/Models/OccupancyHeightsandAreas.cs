﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DOSBPM.Models
{
    public class OccupancyHeightsandAreas
    {
        public string  abandoned { get; set; }

        public string ApplicantComments { get; set; }

        public string ReviewerComments { get; set; }
        public double BuildingHeightinStories { get; set; }
        public double BuildingHeightinFeets { get; set; }
        public double FloorAreainStories { get; set; }
        public double FloorAreainFeets { get; set; }
        public int BuildingYear { get; set; }


        public SelectList ConstructionTypeList { get; set; }
        public SelectList OccupancyTypeList { get; set; }
    }
}