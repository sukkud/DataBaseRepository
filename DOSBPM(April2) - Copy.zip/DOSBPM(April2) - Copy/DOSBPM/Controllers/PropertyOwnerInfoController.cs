﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Configuration;
using System.Data.SqlClient;
using DOSBPM.Models;
using Newtonsoft.Json;
using DOSBPM.Repository;

namespace DOSBPM.Controllers
{
    public class PropertyOwnerInfoController : BaseController
    {
        // GET: PropertyOwnerInfo
        DEV_CODES_APPDB1Entities db = new DEV_CODES_APPDB1Entities();

        public ActionResult Index()
        {
            BuildingApplication buildApp = new BuildingApplication();
            PropertyOwnerInfo propertyOwnerInfo = new PropertyOwnerInfo();

            if (Session["BuildingApplication"] != null)
            {
                buildApp = (BuildingApplication)Session["BuildingApplication"];
            }
            else
            {
                string jsonData = string.Empty;
                temp_BPMData objtemp_BPMData = db.temp_BPMData.FirstOrDefault(x => x.AppID == "1" && x.UserID == "1");
                if (objtemp_BPMData != null)
                {
                    jsonData = objtemp_BPMData.JsonData;
                }
                buildApp = JsonConvert.DeserializeObject<BuildingApplication>(jsonData);
            }
            if (buildApp == null)
            {
                buildApp = new BuildingApplication();
                //buildApp.PropertyOwnerInfoData = new PropertyOwnerInfo();

            }

            //ViewBag.info = new List<SelectListItem> {
            //                                            new SelectListItem {Value="Property Owner Organization", Text="Property Owner Organization", Selected=(buildApp.PropertyOwnerInfoData?.PropertyOwnerType=="Property Owner Organization")},
            //                                            new SelectListItem {Value="Property Owner Individual", Text="Property Owner Individual", Selected=(buildApp.PropertyOwnerInfoData?.PropertyOwnerType=="Property Owner Individual")}

            //                                        };

            buildApp.PropertyOwnerInfoData= (buildApp.PropertyOwnerInfoData == null) ? new PropertyOwnerInfo() : buildApp.PropertyOwnerInfoData;
            buildApp.PropertyOwnerInfoData.AddressInfo = (buildApp.PropertyOwnerInfoData.AddressInfo == null) ? new AddressInfo() : buildApp.PropertyOwnerInfoData.AddressInfo;

            buildApp.PropertyOwnerInfoData.StakeholderTypeList = GetStakeholderTypes();

            AddressInfo objAddressInfo = new AddressInfo();           
            buildApp.PropertyOwnerInfoData.AddressInfo.CountryList = objAddressInfo.CountryList;
            buildApp.PropertyOwnerInfoData.AddressInfo.StatesList = objAddressInfo.StatesList;
            buildApp.PropertyOwnerInfoData.AddressInfo.CountiesList = objAddressInfo.CountiesList;

            //ViewBag.StakeholderTypeList = GetStakeholderTypes();
            //ViewBag.StatesList = GetStates();
            //ViewBag.CountryList = GetCountries();
            //ViewBag.CountiesList = GetCounties();
           
            //buildApp.PropertyOwnerInfoData.StakeholderTypeList = GetStakeholderTypes();

            return View(buildApp.PropertyOwnerInfoData);


        }
        [HttpPost]
        public ActionResult Index(PropertyOwnerInfo propertyOwnerInfo)
        {
            BuildingApplication buildApp = null;
            if (Session["BuildingApplication"] != null)
            {
                buildApp = (BuildingApplication)Session["BuildingApplication"];
            }
            else
            {
                buildApp = new BuildingApplication();
            }

            propertyOwnerInfo.AddressInfo.CountiesList = null;
            propertyOwnerInfo.AddressInfo.StatesList = null;
            propertyOwnerInfo.AddressInfo.CountryList = null;

            buildApp.PropertyOwnerInfoData = propertyOwnerInfo;
            Session["BuildingApplication"] = buildApp;

            string buildAppString = JsonConvert.SerializeObject(buildApp);

            temp_BPMData objtemp_BPMData = db.temp_BPMData.FirstOrDefault(x => x.AppID == "1" && x.UserID == "1");
            if (objtemp_BPMData != null)
            {
                objtemp_BPMData.AppID = "1";
                objtemp_BPMData.UserID = "1";
                objtemp_BPMData.JsonData = buildAppString;
                db.SaveChanges();
            }
            else
            {
                temp_BPMData objtempBPM = new temp_BPMData();
                objtempBPM.AppID = "1";
                objtempBPM.UserID = "1";

                objtempBPM.JsonData = buildAppString;
                db.temp_BPMData.Add(objtempBPM);
                db.SaveChanges();
            }

            return RedirectToAction("Index", "PropertyOwnerContact");
        }
        [HttpPost]
        public JsonResult GetStackHolder(string stackHolder, string type)
        {
            List<StackInfo> stackHolders = new List<StackInfo>();
            var resp = new PropertyInfoData();
            stackHolders = resp.GetStackInfoData(stackHolder, type);
            return Json(stackHolders, JsonRequestBehavior.AllowGet);
        }
    }
}