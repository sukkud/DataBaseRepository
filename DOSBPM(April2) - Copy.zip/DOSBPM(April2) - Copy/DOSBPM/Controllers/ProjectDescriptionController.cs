﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DOSBPM.Models;

namespace DOSBPM.Controllers
{
    public class ProjectDescriptionController : BaseController
    {
        DEV_CODES_APPDB1Entities appdbEntities = new DEV_CODES_APPDB1Entities();

        // GET: ProjectDescription
        public ActionResult Index()
        {
            Log.Info("Project Description Controller Started");

            var objList = new ProjectDescription();            
            objList.WorkTypeList = GetWorkType();

            return View(objList);
            
            
        }
    }
}