﻿var propertyOwnerInfo = (function () {

    var publicMethods = {};

    publicMethods.init = function () {

        $('#ddTransTypes').change(function () {

            propertyOwnerInfo.stackHolderTypeChange();


        });
        //qualify.onTransactionTypeChange();
        var type = propertyOwnerInfo.getType;
        common.autoCompleteInit("serachText1", type);
    }

    publicMethods.stackHolderTypeChange = function () {
        var selected = $("#ddTransTypes").find("option:selected").text();
        if (selected == "Property Owner Organization") {
            $("#PropertyOwnerIndividualPage").hide();
            $("#btnBack").hide();
            $("#PropertyOwnerInformation").show();
            $("#pagebody").show();
        }
        else if (selected == "Property Owner Individual") {
            $("#PropertyOwnerInformation").hide();
            $("#btnBack").hide();
            $("#PropertyOwnerIndividualPage").show();
            //} else if (selected == "Contact Person") {
            //	$("#PropertyOwnerInformation,#PropertyOwnerIndividualPage").hide();
            //	$("#ContactPerson").show();
            $("#pagebody").show();
        }
        else {
            $("#PropertyOwnerInformation,#PropertyOwnerIndividualPage,#pagebody").hide();
        }
    }

    publicMethods.getType = function () {
        var ddPropertyOwnerType = $("#ddTransTypes").val();
        console.log("ddPropertyOwnerType=", ddPropertyOwnerType);
        var type = ""
        if (ddPropertyOwnerType == "SH_1") {
            type = "ORG";
        } else {
            type = "Ind";
        }
        return type;
    }

    publicMethods.onTransactionTypeChange = function () {
        var selectedType = $("#ddTransTypes").find("option:selected").text();
        if (selected == "Property Owner Organization") {
            $("#PropertyOwnerIndividualPage").hide();
            $("#btnBack").hide();
            $("#PropertyOwnerInformation").show();
        }
        else if (selected == "Property Owner Individual") {
            $("#PropertyOwnerInformation").hide();
            $("#btnBack").hide();
            $("#PropertyOwnerIndividualPage").show();
        }
        else {
            $("#PropertyOwnerInformation,#PropertyOwnerIndividualPage").hide();
        }
    }

    publicMethods.resetAddressControls = function () {
        $("#AddressInfo_Address1").val("");
        $("#AddressInfo_Address2").val("");
        $("#AddressInfo_City").val("");
        $("#AddressInfo_CountyId").val("");
        $("#AddressInfo_StateId").val("");
        $("#AddressInfo_Zip").val("");
        $("#AddressInfo_CountryId").val("");
        $("#AddressInfo_Zip4Format").val("");
    }
    publicMethods.validate = function () {
        var isValid = common.validate("PropertyOwnerForm");
        return isValid;
    }





    return publicMethods;
})();